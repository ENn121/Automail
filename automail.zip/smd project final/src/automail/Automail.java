package automail;

import java.util.HashMap;
import java.util.LinkedList;

import exceptions.NoRobotForWorkException;
import strategies.IMailDelivery;
import strategies.IMailGenerator;
import strategies.IMailPool;
import strategies.IRobot;
import strategies.MailDelivery;
import strategies.MailGenerator;
import strategies.MailPool;
import strategies.Robot;

public class Automail {

	private IRobot[] robots;
	private IMailPool mailPool;
	private IMailGenerator mailGenerator;
	private IMailDelivery mailDelivery;
	private LinkedList<IRobot> waitingRobots;

	public Automail(String[] args, PropertyManagement propertyManagement) throws NoRobotForWorkException {
		// Mail_to_Create
		int MAIL_TO_CREATE = Integer.parseInt(propertyManagement.getAutomailProperty("Mail_to_Create"));
		System.out.println("Mail_to_Create: " + MAIL_TO_CREATE);

		// Mail_Max_Weight
		int MAIL_MAX_WEIGHT = Integer.parseInt(propertyManagement.getAutomailProperty("Mail_Max_Weight"));
		System.out.println("Mail_Max_Weight: " + MAIL_MAX_WEIGHT);

		// Last_Delivery_Time
		int LAST_DELIVERY_TIME = Integer.parseInt(propertyManagement.getAutomailProperty("Last_Delivery_Time"));
		System.out.println("Last_Delivery_Time: " + LAST_DELIVERY_TIME);

		// Caution ability
		boolean CAUTION_ENABLED = Boolean.parseBoolean(propertyManagement.getAutomailProperty("Caution"));
		System.out.println("Caution enabled: " + CAUTION_ENABLED);

		// Fragile mail generation
		boolean FRAGILE_ENABLED = Boolean.parseBoolean(propertyManagement.getAutomailProperty("Fragile"));
		System.out.println("Fragile enabled: " + FRAGILE_ENABLED);

		// Statistics tracking
		boolean STATISTICS_ENABLED = Boolean.parseBoolean(propertyManagement.getAutomailProperty("Statistics"));
		System.out.println("Statistics enabled: " + STATISTICS_ENABLED);

		// Robots
		/** Initialize robots */
		int numRobots = Integer.parseInt(propertyManagement.getAutomailProperty("Robots"));
		System.out.println("Robots: " + numRobots);
		if (numRobots == 0)
			throw new NoRobotForWorkException();
		this.robots = new Robot[numRobots];
		assert (this.robots.length > 0);
		for (int i = 0; i < this.robots.length; i++)
			this.robots[i] = new Robot(this, CAUTION_ENABLED);

		// MailPool
		/** Initialize the MailPool */
		this.mailPool = new MailPool(this);

		// Seed
		String seedProp = propertyManagement.getAutomailProperty("Seed");
		/** Used to see whether a seed is initialized or not */
		HashMap<Boolean, Integer> seedMap = new HashMap<>();
		/** Read the first argument and save it as a seed if it exists */
		if (args.length == 0) { // No arg
			if (seedProp == null) { // and no property
				seedMap.put(false, 0); // so randomise
			} else { // Use property seed
				seedMap.put(true, Integer.parseInt(seedProp));
			}
		} else { // Use arg seed - overrides property
			seedMap.put(true, Integer.parseInt(args[0]));
		}
		Integer seed = seedMap.get(true);
		System.out.println("Seed: " + (seed == null ? "null" : seed.toString()));

		// MailGenerator
		/** Initialize the MailGenerator */
		this.mailGenerator = new MailGenerator(this, MAIL_TO_CREATE, MAIL_MAX_WEIGHT, LAST_DELIVERY_TIME,
				FRAGILE_ENABLED, seedMap);

		// MailDelivery
		/** Initialize the MailDelivery */
		this.mailDelivery = new MailDelivery(STATISTICS_ENABLED);

		// waitingRobots
		this.waitingRobots = new LinkedList<IRobot>();
	}

	public IRobot[] getRobots() {
		return this.robots;
	}

	public IMailPool getMailPool() {
		return this.mailPool;
	}

	public IMailGenerator getMailGenerator() {
		return this.mailGenerator;
	}

	public IMailDelivery getMailDelivery() {
		return this.mailDelivery;
	}

	public LinkedList<IRobot> getWaitingRobots() {
		return this.waitingRobots;
	}

	public void registerWaiting(IRobot robot) { // assumes won't be there already
		waitingRobots.add(robot);
	}

}
