package automail;

public class Clock {

	/** Represents the current time **/
	private static int Time = 0;

	// record wrapping and unwrapping time
	private static int specialArmTime = 0;

	public static int Time() {
		return Time;
	}

	public static void Tick() {
		Time++;
	}

	public static void specialWorking() {
		specialArmTime++;
	}

	public static int getSpecialArmTime() {
		return specialArmTime;
	}

}
