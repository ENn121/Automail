package automail;

import java.util.HashMap;

public class Building {

	/** The number of floors in the building **/
	private static int FLOORS;

	/** Represents the ground floor location */
	private static final int LOWEST_FLOOR = 1;

	/** Represents the mailroom location */
	private static final int MAILROOM_LOCATION = 1;

	private static HashMap<Integer, String> cautionFloors = new HashMap<Integer, String>();

	public static void setFLOORS(int FLOORS) {
		Building.FLOORS = FLOORS;
	}

	public static int getFLOORS() {
		return FLOORS;
	}

	public static int getLOWEST_FLOOR() {
		return LOWEST_FLOOR;
	}

	public static int getMAILROOM_LOCATION() {
		return MAILROOM_LOCATION;
	}

	/**
	 * Going to allocate the floors to the robot need fragile delivering, first come
	 * first serve
	 */
	public static boolean setCautionFloors(Integer floor, String id) {
		if (cautionFloors.containsKey(floor))
			return false;
		else {
			cautionFloors.put(floor, id);
			return true;
		}
	}

	public static HashMap<Integer, String> getCautionFloors() {
		return cautionFloors;
	}

	public static void removeCautionFloors(Integer floor) {
		cautionFloors.remove(floor);
	}

}
