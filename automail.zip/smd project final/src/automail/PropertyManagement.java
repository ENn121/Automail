package automail;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class PropertyManagement { // Singleton design pattern

	private static PropertyManagement propertyManagement; // only one PropertyManagement object
	private Properties automailProperties;

	private PropertyManagement() { // set the constructor private

	}

	public static PropertyManagement getPropertyManagementInstance() { // get only one PropertyManagement object
		if (propertyManagement == null) {
			propertyManagement = new PropertyManagement();
		}
		return propertyManagement;
	}

	public void setAutomailProperties(String propertyFileName) throws IOException {
		if (this.automailProperties == null) {
			this.automailProperties = new Properties();
		}
		// Default properties
		this.automailProperties.setProperty("Robots", "Standard");
		this.automailProperties.setProperty("MailPool", "strategies.SimpleMailPool");
		this.automailProperties.setProperty("Floors", "10");
		this.automailProperties.setProperty("Mail_to_Create", "80");
		this.automailProperties.setProperty("Last_Delivery_Time", "100");
		this.automailProperties.setProperty("Caution", "false");
		this.automailProperties.setProperty("Fragile", "false");
		this.automailProperties.setProperty("Statistics", "false");
		// Read properties
		FileReader inStream = null;
		try {
			inStream = new FileReader(propertyFileName);
			this.automailProperties.load(inStream);
		} finally {
			if (inStream != null) {
				inStream.close();
			}
		}
	}

	public String getAutomailProperty(String para) {
		return this.automailProperties.getProperty(para);
	}

}
