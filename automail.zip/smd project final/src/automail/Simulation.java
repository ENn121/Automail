package automail;

import exceptions.ExcessiveDeliveryException;
import exceptions.NoRobotForWorkException;
import strategies.IMailDelivery;
import strategies.IMailGenerator;
import strategies.IMailPool;
import strategies.IRobot;

import java.io.IOException;

/**
 * This class simulates the behaviour of AutoMail
 */
public class Simulation {

	private static PropertyManagement propertyManagement;
	private static Automail automail;

	public static void main(String[] args)
			throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		propertyManagement = PropertyManagement.getPropertyManagementInstance();
		String propertyFileName = "automail.properties";
		automail = simulationSettings(args, propertyManagement, propertyFileName);

		IRobot[] robots = automail.getRobots();
		IMailPool mailPool = automail.getMailPool();
		IMailGenerator mailGenerator = automail.getMailGenerator();
		IMailDelivery mailDelivery = automail.getMailDelivery();

		/** Initiate all the mail */
		mailGenerator.generateAllMail();
		while (mailDelivery.getMailDelivered().size() != mailGenerator.getMailCreated()) {
			mailGenerator.step();
			try {
				mailPool.step();
				for (int i = 0; i < robots.length; i++) {
					robots[i].step();
				}
			} catch (Exception | ExcessiveDeliveryException e) {
				e.printStackTrace();
				System.out.println("Simulation unable to complete.");
				System.exit(0);
			}
			Clock.Tick();
		}
		mailDelivery.printResults();
	}

	public static Automail simulationSettings(String[] args, PropertyManagement propertyManagement,
			String propertyFileName) throws IOException {
		propertyManagement.setAutomailProperties(propertyFileName);

		// Floors
		Building.setFLOORS(Integer.parseInt(propertyManagement.getAutomailProperty("Floors")));
		System.out.println("Floors: " + Building.getFLOORS());

		Automail automail = null;
		try {
			automail = new Automail(args, propertyManagement);
		} catch (NoRobotForWorkException e) {
			e.printStackTrace();
		}
		return automail;
	}

}
