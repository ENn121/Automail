package exceptions;

/**
 * An exception throws when robot wrongly handle fragile item
 */
@SuppressWarnings("serial")
public class BreakingFragileItemException extends Exception {
	public BreakingFragileItemException() {
		super("Breaking Fragile Item!!");
	}
}
