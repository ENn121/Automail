package exceptions;

/**
 * This exception is thrown when the fragile item is not shielded.
 */
@SuppressWarnings("serial")
public class FragileItemNotProtectedException extends Exception {
	public FragileItemNotProtectedException() {
		super("The fragile item is not shielded!");
	}
}
