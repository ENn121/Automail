package exceptions;

/**
 * An exception is thrown when Robots=0
 */
@SuppressWarnings("serial")
public class NoRobotForWorkException extends Exception {
	public NoRobotForWorkException() {
		super("There is no robot for work!");
	}
}
