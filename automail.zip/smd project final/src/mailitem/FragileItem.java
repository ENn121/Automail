package mailitem;

import automail.Clock;
import exceptions.FragileItemNotProtectedException;

public class FragileItem extends MailItem {

	/** The first shield */
	protected boolean shieldFirst;
	/** The second shield */
	protected boolean shieldSecond;

	/**
	 * Constructor for the FragileItem
	 *
	 * @param dest_floor   the destination floor intended for this mail item
	 * @param arrival_time the time that the mail arrived
	 * @param weight       the weight of this mail item
	 */
	public FragileItem(int dest_floor, int arrival_time, int weight) {
		super(dest_floor, arrival_time, weight);
		this.shieldFirst = false;
		this.shieldSecond = false;
	}

	public boolean isShieldFirst() {
		return this.shieldFirst;
	}

	public boolean isShieldSecond() {
		return this.shieldSecond;
	}

	/**
	 * wrap the first seal of the item
	 */
	public void wrapFirst() {
		this.shieldFirst = true;
		Clock.specialWorking();
		System.out.printf("T: %3d > SealFirst   [%s] %n", Clock.Time(), this.toString());
	}

	/**
	 * wrap the second seal of the item
	 */
	public void wrapSecond() {
		this.shieldSecond = true;
		Clock.specialWorking();
		System.out.printf("T: %3d > SealSecond  [%s] %n", Clock.Time(), this.toString());
	}

	/**
	 * Unwrap the item
	 */
	public void unwrap() throws FragileItemNotProtectedException {
		if (!this.shieldFirst || !this.shieldSecond)
			throw new FragileItemNotProtectedException();
		this.shieldFirst = false;
		this.shieldSecond = false;
		Clock.specialWorking();
		System.out.printf("T: %3d > Unwrap      [%s] %n", Clock.Time(), this.toString());
	}

	/**
	 * protection judges
	 */
	public boolean isProtected() {
		return (this.shieldFirst && this.shieldSecond);
	}

	@Override
	public String toString() {
		return String.format("Mail Item: ID: %6s | Arrival: %4d | Destination: %2d | Weight: %4d | %7s", id,
				arrival_time, destination_floor, weight, "fragile");
	}

}
