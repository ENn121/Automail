package strategies;

import java.util.*;

import automail.Automail;
import automail.Building;
import automail.Clock;
import mailitem.FragileItem;
import mailitem.MailItem;
import mailitem.OrdinaryItem;

/**
 * This class generates the mail
 */
public class MailGenerator implements IMailGenerator {

	private Automail automail;
	/** Constant for the mail generator */
	private final int MAIL_TO_CREATE;
	private final int MAIL_MAX_WEIGHT;
	/** The threshold for the latest time for mail to arrive **/
	private int LAST_DELIVERY_TIME;
	private boolean FRAGILE_ENABLED;
	/** This seed is used to make the behaviour deterministic */
	private final Random random;
	private int mailCreated;
	private boolean complete;
	private Map<Integer, ArrayList<MailItem>> allMail;

	/**
	 * Constructor for mail generation
	 */
	public MailGenerator(Automail automail, int mailToCreate, int mailMaxWeight, int LAST_DELIVERY_TIME,
			boolean FRAGILE_ENABLED, HashMap<Boolean, Integer> seed) {
		this.automail = automail;
		if (seed.containsKey(true)) {
			this.random = new Random((long) seed.get(true));
		} else {
			this.random = new Random();
		}
		// Vary arriving mail by +/-20%
		this.MAIL_TO_CREATE = mailToCreate * 4 / 5 + this.random.nextInt(mailToCreate * 2 / 5);
		// System.out.println("Num Mail Items: "+MAIL_TO_CREATE);
		this.MAIL_MAX_WEIGHT = mailMaxWeight;
		this.LAST_DELIVERY_TIME = LAST_DELIVERY_TIME;
		this.FRAGILE_ENABLED = FRAGILE_ENABLED;
		this.mailCreated = 0;
		this.complete = false;
		this.allMail = new HashMap<Integer, ArrayList<MailItem>>();
	}

	/**
	 * @return a new mail item that needs to be delivered
	 */
	private MailItem generateMail(boolean generateFragile) {
		int dest_floor = generateDestinationFloor();
		int arrival_time = generateArrivalTime();
		int weight = generateWeight();
		boolean isFragile = generateFragile && generateFragile();
		if (isFragile)
			return new FragileItem(dest_floor, arrival_time, weight);
		else
			return new OrdinaryItem(dest_floor, arrival_time, weight);
	}

	private boolean generateFragile() {
		final int chance = 4; // 1 in chance of being fragile
		return this.random.nextInt(chance) + 1 >= chance;
		// return random.nextBoolean();
	}

	/**
	 * @return a destination floor between the ranges of GROUND_FLOOR to FLOOR
	 */
	private int generateDestinationFloor() {
		return Building.getLOWEST_FLOOR() + this.random.nextInt(Building.getFLOORS());
	}

	/**
	 * @return a random weight
	 */
	private int generateWeight() {
		final double mean = 200.0; // grams for normal item
		final double stddev = 1000.0; // grams
		double base = this.random.nextGaussian();
		if (base < 0)
			base = -base;
		int weight = (int) (mean + base * stddev);
		return Math.min(weight, this.MAIL_MAX_WEIGHT);
	}

	/**
	 * @return a random arrival time before the last delivery time
	 */
	private int generateArrivalTime() {
		return 1 + this.random.nextInt(this.LAST_DELIVERY_TIME);
	}

	/**
	 * This class initializes all mail and sets their corresponding values,
	 */
	@Override
	public void generateAllMail() {
		while (!this.complete) {
			MailItem newMail = generateMail(this.FRAGILE_ENABLED);
			int timeToDeliver = newMail.getArrivalTime();
			/** Check if key exists for this time **/
			if (this.allMail.containsKey(timeToDeliver)) {
				/** Add to existing array */
				this.allMail.get(timeToDeliver).add(newMail);
			} else {
				/**
				 * If the key doesn't exist then set a new key along with the array of MailItems
				 * to add during that time step.
				 */
				ArrayList<MailItem> newMailList = new ArrayList<MailItem>();
				newMailList.add(newMail);
				this.allMail.put(timeToDeliver, newMailList);
			}
			/** Mark the mail as created */
			this.mailCreated++;

			/** Once we have satisfied the amount of mail to create, we're done! */
			if (this.mailCreated == this.MAIL_TO_CREATE) {
				this.complete = true;
			}
		}
	}

	/**
	 * While there are steps left, create a new mail item to deliver
	 */
	@Override
	public void step() {
		// Check if there are any mail to create
		if (this.allMail.containsKey(Clock.Time())) {
			for (MailItem mailItem : this.allMail.get(Clock.Time())) {
				System.out.printf("T: %3d > + addToPool [%s]%n", Clock.Time(), mailItem.toString());
				this.automail.getMailPool().addToPool(mailItem);
			}
		}
	}

	@Override
	public int getMailCreated() {
		return this.mailCreated;
	}

}
