package strategies;

import java.util.Collections;
import java.util.LinkedList;
import java.util.ListIterator;

import automail.Automail;
import exceptions.BreakingFragileItemException;
import exceptions.ItemTooHeavyException;
import mailitem.FragileItem;
import mailitem.MailItem;
import mailitem.OrdinaryItem;

public class MailPool implements IMailPool {

	private Automail automail;
	private LinkedList<MailItem> ordPool;
	private LinkedList<MailItem> fragilePool;

	public MailPool(Automail automail) {
		// Start empty
		this.automail = automail;
		this.ordPool = new LinkedList<MailItem>();
		this.fragilePool = new LinkedList<MailItem>();
	}

	@Override
	public void addToPool(MailItem mailItem) {
		if (mailItem instanceof FragileItem) {
			this.fragilePool.add(mailItem);
			Collections.sort(this.fragilePool);
		} else if (mailItem instanceof OrdinaryItem) {
			this.ordPool.add(mailItem);
			Collections.sort(this.ordPool);
		}
	}

	@Override
	public void step() throws ItemTooHeavyException, BreakingFragileItemException {
		try {
			ListIterator<IRobot> i = this.automail.getWaitingRobots().listIterator();
			while (i.hasNext())
				loadRobot(i);
		} catch (Exception e) {
			throw e;
		}
	}

	private void loadRobot(ListIterator<IRobot> i) throws ItemTooHeavyException, BreakingFragileItemException {
		IRobot robot = i.next();
		assert (robot.isEmpty());
		// System.out.printf("P: %3d%n", pool.size());
		ListIterator<MailItem> o = this.fragilePool.listIterator();
		ListIterator<MailItem> j = this.ordPool.listIterator();
		if (this.fragilePool.size() > 0 || this.ordPool.size() > 0) {
			// try to dig in the fragile pool first and find items in the ordinary pool
			try {
				if (this.fragilePool.size() > 0) {
					robot.addToHand(o.next());
					o.remove();
				}
				if (this.ordPool.size() > 0) {
					robot.addToHand(j.next());
					j.remove();
					if (this.ordPool.size() > 0) {
						robot.addToTube(j.next());
						j.remove();
					}
				}
				robot.dispatch(); // send the robot off if it has any items to deliver
				i.remove(); // remove from mailPool queue
			} catch (Exception e) {
				throw e;
			}
		}
	}

}
