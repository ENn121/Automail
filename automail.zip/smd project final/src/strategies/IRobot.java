package strategies;

import exceptions.BreakingFragileItemException;
import exceptions.ExcessiveDeliveryException;
import exceptions.FragileItemNotProtectedException;
import exceptions.ItemTooHeavyException;
import mailitem.MailItem;

/**
 * This is the interface of the Robot.
 */
public interface IRobot {

	public void dispatch();

	public void step() throws ExcessiveDeliveryException, FragileItemNotProtectedException;

	public boolean isEmpty();

	public void addToHand(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException;

	public void addToTube(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException;

}
