package strategies;

import java.util.Map;
import java.util.TreeMap;

import automail.Automail;
import automail.Building;
import automail.Clock;
import exceptions.BreakingFragileItemException;
import exceptions.ExcessiveDeliveryException;
import exceptions.FragileItemNotProtectedException;
import exceptions.ItemTooHeavyException;
import mailitem.FragileItem;
import mailitem.MailItem;
import mailitem.OrdinaryItem;

/**
 * The robot delivers mail!
 */
public class Robot implements IRobot {

	private static final int INDIVIDUAL_MAX_WEIGHT = 2000;

	private Automail automail;
	private final String id;

	/** Possible states the robot can be in */
	private enum RobotState {
		DELIVERING, WAITING, RETURNING
	}

	private RobotState current_state;
	private int current_floor;
	private int destination_floor;
	private boolean receivedDispatch;
	private boolean CAUTION_ENABLED;

	private OrdinaryItem deliveryItem = null;
	private OrdinaryItem tube = null;
	private FragileItem specialItem = null; // fragile hand

	private int deliveryCounter;

	private static int count = 0;
	private static Map<Integer, Integer> hashMap = new TreeMap<Integer, Integer>();

	/**
	 * Initiates the robot's location at the start to be at the mailroom also set it
	 * to be waiting for mail.
	 */
	public Robot(Automail automail, boolean CAUTION_ENABLED) {
		this.automail = automail;
		this.id = "R" + hashCode();
		// current_state = RobotState.WAITING;
		this.current_state = RobotState.RETURNING;
		this.current_floor = Building.getMAILROOM_LOCATION();
		this.receivedDispatch = false;
		this.deliveryCounter = 0;
		this.CAUTION_ENABLED = CAUTION_ENABLED;
	}

	@Override
	public void dispatch() {
		receivedDispatch = true;
	}

	/**
	 * This is called on every time step
	 */
	@Override
	public void step() throws ExcessiveDeliveryException, FragileItemNotProtectedException {
		switch (current_state) {
		/**
		 * This state is triggered when the robot is returning to the mailroom after a
		 * delivery
		 */
		case RETURNING: {
			/**
			 * If its current position is at the mailroom, then the robot should change
			 * state
			 */
			if (current_floor == Building.getMAILROOM_LOCATION()) {
				if (tube != null) {
					this.automail.getMailPool().addToPool(tube);
					System.out.printf("T: %3d >  +addToPool [%s]%n", Clock.Time(), tube.toString());
					tube = null;
				}
				/** Tell the sorter the robot is ready */
				this.automail.registerWaiting(this);
				changeState(RobotState.WAITING);
			} else {
				/** If the robot is not at the mailroom floor yet, then move towards it! */
				moveTowards(Building.getMAILROOM_LOCATION());
				break;
			}
		}
		case WAITING:
			/**
			 * If the StorageTube is ready and the Robot is waiting in the mailroom then
			 * start the delivery
			 */
			if (destination_floor == -1) {
				// if -1 means you cannot set route successfully , the destination floor is
				// occupied by another one
				if (setRoute()) // attempt to set the destination
					changeState(RobotState.DELIVERING);
				else
					break;
			}
			if (CAUTION_ENABLED && specialItem != null) {
				// the robot is waiting and in caution mode and has fragile item allocated
				if (!specialItem.isShieldFirst()) { // try to wrap it
					specialItem.wrapFirst();
					break;
				} else if (!specialItem.isShieldSecond()) {
					specialItem.wrapSecond();
					break;
				}
			}
			if (!isEmpty() && receivedDispatch) {
				receivedDispatch = false;
				deliveryCounter = 0; // reset delivery counter
				if (setRoute())
					changeState(RobotState.DELIVERING);
			}
			break;
		case DELIVERING:
			if (CAUTION_ENABLED) {
				if (destination_floor == -1) {
					// if -1 means you cannot set route successfully , the caution target is
					// occupied by another one
					if (setRoute())
						changeState(RobotState.DELIVERING);
					else
						break;
				}
				if (specialItem != null && destination_floor == specialItem.getDestFloor()) {
					deliverSpecialJudge();// in the process of delivering the fragile item
				} else {
					deliverOrdJudge(); // in the process of delivering ordinary item
				}
			} else {
				deliverOrdJudge();
				/**
				 * if the robot is on the destination floor and the item is wrapped, unwrap if
				 * the robot is on the destination floor and the item is unwrapped, deliver and
				 * turn to returning status if the robot is not on the destination floor, move
				 * forward
				 */
			}
			break;
		}
	}

	private void deliverOrdJudge() throws ExcessiveDeliveryException { // logic on how to deliver ordinary stuffs
		if (current_floor == destination_floor) { // If already here drop off either way
			/** Delivery complete, report this to the simulator! */
			this.automail.getMailDelivery().deliver(deliveryItem);
			deliveryItem = null;
			deliveryCounter++;
			if (deliveryCounter > 2) { // Implies a simulation bug
				throw new ExcessiveDeliveryException();
			}
			/** Check if want to return, i.e. if there is no item in the tube */
			if (tube == null && specialItem == null) {
				changeState(RobotState.RETURNING); // with all hand empty, go back to mailroom
			} else {
				/**
				 * If there is another item, set the robot's route to the location to deliver
				 * the item
				 */
				if (tube != null)
					deliveryItem = tube;
				tube = null;
				if (setRoute()) // if you can successfully set the route , change the state
					changeState(RobotState.DELIVERING);
			}
		} else {
			/** The robot is not at the destination yet, move towards it! */
			moveTowards(destination_floor);
		}
	}

	private void deliverSpecialJudge() throws FragileItemNotProtectedException {
		if (current_floor == destination_floor && specialItem.isProtected()) { // protected and unwrap it
			specialItem.unwrap();
		} else if (current_floor == destination_floor && !specialItem.isProtected()) { // deliver the item if unsealed
			this.automail.getMailDelivery().deliver(specialItem);
			Building.removeCautionFloors(destination_floor);
			specialItem = null;
			if (deliveryItem != null) {
				if (setRoute())
					changeState(RobotState.DELIVERING);
			} else {
				changeState(RobotState.RETURNING);
			}
		} else {
			moveTowards(destination_floor);
		}
	}

	/**
	 * Sets the route for the robot send the further one first
	 */
	private boolean setRoute() {
		/**
		 * set the destination floor, if succeed, return true, or the robot is told to
		 * hang for this round
		 */
		if (specialItem == null) {
			destination_floor = deliveryItem.getDestFloor();
			return true;
		}
		if (deliveryItem == null) {
			int destination = specialItem.getDestFloor();
			if (Building.setCautionFloors(destination, this.id)) {
				destination_floor = destination;
				return true;
			} else {
				destination_floor = -1;
				return false;
			}
		} else {
			/**
			 * if both are not null ,find the nearest one first.
			 */
			int orddistance = Math.abs(deliveryItem.getDestFloor() - current_floor);
			int specdistance = Math.abs(specialItem.getDestFloor() - current_floor);
			destination_floor = orddistance < specdistance ? deliveryItem.getDestFloor() : specialItem.getDestFloor();
			if (destination_floor == specialItem.getDestFloor()
					&& Building.setCautionFloors(destination_floor, this.id)) {
				return true;
			} else if (destination_floor == deliveryItem.getDestFloor()) {
				return true;
			} else {
				destination_floor = -1;
				return false;
			}
		}
	}

	/**
	 * Generic function that moves the robot towards the destination
	 * 
	 * @param destination the floor towards which the robot is moving
	 */
	private void moveTowards(int destination) {
		if (current_floor < destination) {
			if (specialItem != null) {
				if (Building.getCautionFloors().containsKey(current_floor + 1)) {
					if (!Building.getCautionFloors().get(current_floor + 1).equals(this.id)) {
						// if the next floor is booked, the robot has to wait to move
					} else {
						current_floor++;
					}
				} else
					current_floor++;
			} else {
				if (Building.getCautionFloors().containsKey(current_floor + 1)) {
				} else
					current_floor++;
			}
		} else {
			if (specialItem != null) {
				if (Building.getCautionFloors().containsKey(current_floor - 1)) {
					if (!Building.getCautionFloors().get(current_floor - 1).equals(this.id)) {
						// if the next floor is booked, the robot has to wait to move
					} else {
						current_floor--;
					}
				} else
					current_floor--;
			} else {
				if (Building.getCautionFloors().containsKey(current_floor - 1)) {
				} else
					current_floor--;
			}
		}
	}

	private String getIdTube() {
		return String.format("%s(%1d)", this.id, (tube == null ? 0 : 1));
	}

	/**
	 * Prints out the change in state
	 * 
	 * @param nextState the state to which the robot is transitioning
	 */
	private void changeState(RobotState nextState) {
		assert (!(deliveryItem == null && tube != null) || (specialItem == null));
		if (current_state != nextState) {
			System.out.printf("T: %3d > %7s changed from %s to %s%n", Clock.Time(), getIdTube(), current_state,
					nextState);
		}
		current_state = nextState;
		if (nextState == RobotState.DELIVERING) {
			if (deliveryItem != null && destination_floor == deliveryItem.getDestFloor()) {
				System.out.printf("T: %3d > %9s-> [%s]%n", Clock.Time(), getIdTube(), deliveryItem.toString());
			}
			if (specialItem != null && destination_floor == specialItem.getDestFloor())
				System.out.printf("T: %3d > %9s-> [%s]%n", Clock.Time(), getIdTube(), specialItem.toString());
		}
	}

	public MailItem getTube() {
		return tube;
	}

	@Override
	public int hashCode() {
		Integer hash0 = super.hashCode();
		Integer hash = hashMap.get(hash0);
		if (hash == null) {
			hash = count++;
			hashMap.put(hash0, hash);
		}
		return hash;
	}

	@Override
	public boolean isEmpty() {
		if (CAUTION_ENABLED)
			return (deliveryItem == null && tube == null && specialItem == null);
		else
			return (deliveryItem == null && tube == null);
	}

	@Override
	public void addToHand(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
		if (CAUTION_ENABLED && specialItem == null) {
			if (mailItem instanceof FragileItem) {
				specialItem = (FragileItem) mailItem;
				if (specialItem.getWeight() > INDIVIDUAL_MAX_WEIGHT)
					throw new ItemTooHeavyException();
				return;
			}
		}
		if (mailItem instanceof FragileItem)
			throw new BreakingFragileItemException();
		deliveryItem = (OrdinaryItem) mailItem;
		if (deliveryItem.getWeight() > INDIVIDUAL_MAX_WEIGHT)
			throw new ItemTooHeavyException();
	}

	@Override
	public void addToTube(MailItem mailItem) throws ItemTooHeavyException, BreakingFragileItemException {
		assert (tube == null);
		if (mailItem instanceof FragileItem)
			throw new BreakingFragileItemException();
		tube = (OrdinaryItem) mailItem;
		if (tube.getWeight() > INDIVIDUAL_MAX_WEIGHT)
			throw new ItemTooHeavyException();
	}

}
