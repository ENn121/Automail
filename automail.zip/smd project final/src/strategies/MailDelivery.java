package strategies;

import java.util.ArrayList;

import automail.Clock;
import exceptions.MailAlreadyDeliveredException;
import mailitem.FragileItem;
import mailitem.MailItem;
import mailitem.OrdinaryItem;

public class MailDelivery implements IMailDelivery {

	private final boolean STATISTICS_ENABLED;
	private final ArrayList<MailItem> MAIL_DELIVERED; // End properties
	private double total_score = 0;

	public MailDelivery(boolean STATISTICS_ENABLED) {
		this.STATISTICS_ENABLED = STATISTICS_ENABLED;
		this.MAIL_DELIVERED = new ArrayList<MailItem>();
	}

	@Override
	public ArrayList<MailItem> getMailDelivered() {
		return this.MAIL_DELIVERED;
	}

	/** Confirm the delivery and calculate the total score */
	@Override
	public void deliver(MailItem deliveryItem) {
		if (!this.MAIL_DELIVERED.contains(deliveryItem)) {
			this.MAIL_DELIVERED.add(deliveryItem);
			System.out.printf("T: %3d > Deliv(%4d) [%s]%n", Clock.Time(), this.MAIL_DELIVERED.size(),
					deliveryItem.toString());
			// Calculate delivery score
			this.total_score += calculateDeliveryScore(deliveryItem);
		} else {
			try {
				throw new MailAlreadyDeliveredException();
			} catch (MailAlreadyDeliveredException e) {
				e.printStackTrace();
			}
		}
	}

	private double calculateDeliveryScore(MailItem deliveryItem) {
		// Penalty for longer delivery times
		final double penalty = 1.2;
		double priority_weight = 0;
		return Math.pow(Clock.Time() - deliveryItem.getArrivalTime(), penalty) * (1 + Math.sqrt(priority_weight));
	}

	@Override
	public void printResults() {
		if (this.STATISTICS_ENABLED) {
			ArrayList<MailItem> ORD_MAIL_DELIVERED = new ArrayList<MailItem>();
			ArrayList<MailItem> CAUTION_MAIL_DELIVERED = new ArrayList<MailItem>();
			for (MailItem deliveryItem : MAIL_DELIVERED) {
				if (deliveryItem instanceof FragileItem) {
					CAUTION_MAIL_DELIVERED.add(deliveryItem);
				} else if (deliveryItem instanceof OrdinaryItem) {
					ORD_MAIL_DELIVERED.add(deliveryItem);
				}
			}
			System.out.println("The number of packages delivered normally: " + ORD_MAIL_DELIVERED.size());
			System.out.println("The number of packages delivered using caution: " + CAUTION_MAIL_DELIVERED.size());
			int ordWeight = 0;
			for (MailItem item : ORD_MAIL_DELIVERED) {
				ordWeight += item.getWeight();
			}
			System.out.println("The total weight of the packages delivered normally: " + ordWeight);
			int cautionWeight = 0;
			for (MailItem item : CAUTION_MAIL_DELIVERED) {
				cautionWeight += item.getWeight();
			}
			System.out.println("The total weight of the packages delivered using caution: " + cautionWeight);
			System.out.println("Wrapping & Unwrapping time in total: " + Clock.getSpecialArmTime());
		}
		System.out.println("T: " + Clock.Time() + " | Simulation complete!");
		System.out.println("Final Delivery time: " + Clock.Time());
		System.out.printf("Final Score: %.2f%n", this.total_score);
	}

}
