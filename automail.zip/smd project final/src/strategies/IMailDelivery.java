package strategies;

import java.util.ArrayList;

import mailitem.MailItem;

/**
 * a MailDelivery is used by the Robot to deliver mail once it has arrived at
 * the correct location, it can also get the mail delivered and print the final
 * results after all mails have been delivered.
 */
public interface IMailDelivery {

	public ArrayList<MailItem> getMailDelivered();

	/**
	 * Delivers an item at its floor
	 * 
	 * @param mailItem the mail item being delivered.
	 */
	public void deliver(MailItem mailItem);

	public void printResults();

}
