package strategies;

/**
 * This is the interface of the MailGenerator.
 */
public interface IMailGenerator {

	public void generateAllMail();

	public void step();

	public int getMailCreated();

}
